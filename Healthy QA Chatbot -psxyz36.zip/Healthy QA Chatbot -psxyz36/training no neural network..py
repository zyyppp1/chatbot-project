# 导入所需的库
import numpy as np
import random
import json
import pickle
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Embedding, SpatialDropout1D, Dropout
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
import tensorflow as tf
import nltk
from nltk.stem import WordNetLemmatizer

# 初始化 NLTK 的 WordNet
nltk.download('wordnet')
nltk.download('punkt')

# 加载和处理意图文件
lemmatizer = WordNetLemmatizer()
intents = json.loads(open('intents.json').read())

words = []
classes = []
documents = []
ignore_letters = ['?', '!', '.', ',']

for intent in intents['intents']:
    for pattern in intent['patterns']:
        # 分词
        word_list = nltk.word_tokenize(pattern)
        words.extend(word_list)
        documents.append((word_list, intent['tag']))
        if intent['tag'] not in classes:
            classes.append(intent['tag'])

# 数据预处理
words = [lemmatizer.lemmatize(word) for word in words if word not in ignore_letters]
words = sorted(set(words))
classes = sorted(set(classes))

# 保存词汇和类别
pickle.dump(words, open('words.pkl', 'wb'))
pickle.dump(classes, open('classes.pkl', 'wb'))

# 准备训练数据
training = []
output_empty = [0] * len(classes)

for document in documents:
    bag = []
    word_patterns = document[0]
    word_patterns = [lemmatizer.lemmatize(word.lower()) for word in word_patterns]
    for word in words:
        bag.append(1 if word in word_patterns else 0)
    output_row = list(output_empty)
    output_row[classes.index(document[1])] = 1
    training.append(bag + output_row)

random.shuffle(training)
training = np.array(training)
train_x = training[:, :len(words)]
train_y = training[:, len(words):]

# 定义神经网络模型用于聊天机器人
chatbot_model = Sequential([
    Dense(128, input_shape=(len(train_x[0]),), activation='relu'),
    Dropout(0.5),
    Dense(64, activation='relu'),
    Dropout(0.5),
    Dense(len(train_y[0]), activation='softmax')
])

sgd = tf.keras.optimizers.SGD(lr=0.01, momentum=0.9, nesterov=True)
chatbot_model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])

# 训练模型
chatbot_model.fit(train_x, train_y, epochs=200, batch_size=5, verbose=1)
chatbot_model.save('chatbot_model.h5')
print('Chatbot model trained and saved.')

# 现有模型训练和评估
# 假设X, y已经准备好，是特征集和标签集
X = np.random.randn(1000, 10)  # 示例特征数据
y = np.random.randint(0, 2, size=(1000,))  # 示例标签数据，二分类任务

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 定义训练和评估函数
def train_evaluate_model(model, X_train, X_test, y_train, y_test, is_neural_net=False):
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    acc = accuracy_score(y_test, predictions)
    f1 = f1_score(y_test, predictions, average='weighted')
    prec = precision_score(y_test, predictions, average='weighted')
    rec = recall_score(y_test, predictions, average='weighted')
    print(f"Model: {model.__class__.__name__} - Accuracy: {acc}, F1Score: {f1}, Precision: {prec}, Recall: {rec}")

# 逻辑回归模型
lr_model = LogisticRegression()
train_evaluate_model(lr_model, X_train, X_test, y_train, y_test)

# 随机森林模型
rf_model = RandomForestClassifier()
train_evaluate_model(rf_model, X_train, X_test, y_train, y_test)

# 支持向量机模型
svm_model = SVC()
train_evaluate_model(svm_model, X_train, X_test, y_train, y_test)

# 多层感知机模型
mlp_model = MLPClassifier()
train_evaluate_model(mlp_model, X_train, X_test, y_train, y_test)

# LSTM模型 - 需要特别注意输入的处理
lstm_model = Sequential([
    Embedding(input_dim=1000, output_dim=128, input_length=10),
    SpatialDropout1D(0.2),
    LSTM(100, dropout=0.2, recurrent_dropout=0.2),
    Dense(1, activation='sigmoid')
])
lstm_model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
lstm_model.fit(X_train, y_train, epochs=5, batch_size=64)
# 评估LSTM模型
predictions = (lstm_model.predict(X_test) > 0.5).astype("int32")
acc = accuracy_score(y_test, predictions)
f1 = f1_score(y_test, predictions, average='weighted')
prec = precision_score(y_test, predictions, average='weighted')
rec = recall_score(y_test, predictions, average='weighted')
print(f"Model: LSTM - Accuracy: {acc}, F1 Score: {f1}, Precision: {prec}, Recall: {rec}")

print("All models trained and evaluated.")
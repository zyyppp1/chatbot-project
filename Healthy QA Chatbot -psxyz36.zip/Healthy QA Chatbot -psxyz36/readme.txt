Here is the coursework for design intelligent agent,
firstly, you need to run training.py to use neural network to train the data intents.jason to chatbot_model.keras and several pkl files.
Then you can run gui.py for the chatbot with UI , you can also run chatbot.py to see how it runs in your pycharm/visual studio code as you like .